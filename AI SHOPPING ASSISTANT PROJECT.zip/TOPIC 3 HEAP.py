

class AVLNode:
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.height = 1
        self.left = None
        self.right = None

def get_height(node):
    return node.height if node else 0

def get_balance(node):
    return get_height(node.left) - get_height(node.right) if node else 0

def rotate_right(y):
    x = y.left
    T2 = x.right
    x.right = y
    y.left = T2
    y.height = 1 + max(get_height(y.left), get_height(y.right))
    x.height = 1 + max(get_height(x.left), get_height(x.right))
    return x

def rotate_left(x):
    y = x.right
    T2 = y.left
    y.left = x
    x.right = T2
    x.height = 1 + max(get_height(x.left), get_height(x.right))
    y.height = 1 + max(get_height(y.left), get_height(y.right))
    return y

def insert_avl(root, key, value):
    if not root:
        return AVLNode(key, value)
    if key < root.key:
        root.left = insert_avl(root.left, key, value)
    elif key > root.key:
        root.right = insert_avl(root.right, key, value)
    else:
        return root

    root.height = 1 + max(get_height(root.left), get_height(root.right))
    balance = get_balance(root)

    if balance > 1 and key < root.left.key:
        return rotate_right(root)
    if balance < -1 and key > root.right.key:
        return rotate_left(root)
    if balance > 1 and key > root.left.key:
        root.left = rotate_left(root.left)
        return rotate_right(root)
    if balance < -1 and key < root.right.key:
        root.right = rotate_right(root.right)
        return rotate_left(root)

    return root

class BSTNode:
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.left = None
        self.right = None

def insert_bst(root, key, value):
    if not root:
        return BSTNode(key, value)
    if key < root.key:
        root.left = insert_bst(root.left, key, value)
    elif key > root.key:
        root.right = insert_bst(root.right, key, value)
    return root

def search_bst(root, key):
    if not root or root.key == key:
        return root
    if key < root.key:
        return search_bst(root.left, key)
    return search_bst(root.right, key)


import heapq

def add_to_heap(heap, priority, product):
    heapq.heappush(heap, (priority, product))

def get_top_from_heap(heap):
    return heapq.heappop(heap)
if __name__ == "__main__":
    
    print("AVL Tree Example")
    avl_tree = None
    avl_tree = insert_avl(avl_tree, 101, "Product A")
    avl_tree = insert_avl(avl_tree, 102, "Product B")
    avl_tree = insert_avl(avl_tree, 100, "Product C")
    print("AVL Tree Root:", avl_tree.key, avl_tree.value)

    
    print("\nBST Example")
    bst_tree = None
    bst_tree = insert_bst(bst_tree, 201, "Preference A")
    bst_tree = insert_bst(bst_tree, 202, "Preference B")
    bst_tree = insert_bst(bst_tree, 200, "Preference C")
    print("BST Root:", bst_tree.key, bst_tree.value)
    search_result = search_bst(bst_tree, 202)
    print("Search Result for Key 202:", search_result.key, search_result.value)

    
    print("\nHeap Example")
    product_heap = []
    add_to_heap(product_heap, 5, "Product X")
    add_to_heap(product_heap, 3, "Product Y")
    add_to_heap(product_heap, 4, "Product Z")

    print("Heap Contents (Priority, Product):")
    while product_heap:
        print(get_top_from_heap(product_heap))
