

class AVLNode:
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.height = 1
        self.left = None
        self.right = None

def get_height(node):
    return node.height if node else 0

def get_balance(node):
    return get_height(node.left) - get_height(node.right) if node else 0

def rotate_right(y):
    x = y.left
    T2 = x.right
    x.right = y
    y.left = T2
    y.height = 1 + max(get_height(y.left), get_height(y.right))
    x.height = 1 + max(get_height(x.left), get_height(x.right))
    return x

def rotate_left(x):
    y = x.right
    T2 = y.left
    y.left = x
    x.right = T2
    x.height = 1 + max(get_height(x.left), get_height(x.right))
    y.height = 1 + max(get_height(y.left), get_height(y.right))
    return y

def insert_avl(root, key, value):
    if not root:
        return AVLNode(key, value)
    if key < root.key:
        root.left = insert_avl(root.left, key, value)
    elif key > root.key:
        root.right = insert_avl(root.right, key, value)
    else:
        return root

    root.height = 1 + max(get_height(root.left), get_height(root.right))
    balance = get_balance(root)

    if balance > 1 and key < root.left.key:
        return rotate_right(root)
    if balance < -1 and key > root.right.key:
        return rotate_left(root)
    if balance > 1 and key > root.left.key:
        root.left = rotate_left(root.left)
        return rotate_right(root)
    if balance < -1 and key < root.right.key:
        root.right = rotate_right(root.right)
        return rotate_left(root)

    return root

class BSTNode:
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.left = None
        self.right = None

def insert_bst(root, key, value):
    if not root:
        return BSTNode(key, value)
    if key < root.key:
        root.left = insert_bst(root.left, key, value)
    elif key > root.key:
        root.right = insert_bst(root.right, key, value)
    return root

def search_bst(root, key):
    if not root or root.key == key:
        return root
    if key < root.key:
        return search_bst(root.left, key)
    return search_bst(root.right, key)


import heapq

def add_to_heap(heap, priority, product):
    heapq.heappush(heap, (priority, product))

def get_top_from_heap(heap):
    return heapq.heappop(heap)

class LinkedListNode:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        new_node = LinkedListNode(data)
        if not self.head:
            self.head = new_node
        else:
            temp = self.head
            while temp.next:
                temp = temp.next
            temp.next = new_node

    def display(self):
        temp = self.head
        while temp:
            print(temp.data, end=" -> ")
            temp = temp.next
        print("None")

class BinaryTreeNode:
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.left = None
        self.right = None

def insert_binary_tree(root, key, value):
    if not root:
        return BinaryTreeNode(key, value)
    queue = [root]
    while queue:
        temp = queue.pop(0)
        if not temp.left:
            temp.left = BinaryTreeNode(key, value)
            break
        else:
            queue.append(temp.left)
        if not temp.right:
            temp.right = BinaryTreeNode(key, value)
            break
        else:
            queue.append(temp.right)
    return root

def inorder_traversal(root):
    if root:
        inorder_traversal(root.left)
        print(f"{root.key}: {root.value}", end=" | ")
        inorder_traversal(root.right)


class TreeNode:
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.children = []

def add_child(parent, key, value):
    child = TreeNode(key, value)
    parent.children.append(child)
    return child

def display_tree(node, level=0):
    print("  " * level + f"{node.key}: {node.value}")
    for child in node.children:
        display_tree(child, level + 1)

if __name__ == "__main__":
   
    print("AVL Tree Example")
    avl_tree = None
    avl_tree = insert_avl(avl_tree, 101, "Product A")
    avl_tree = insert_avl(avl_tree, 102, "Product B")
    avl_tree = insert_avl(avl_tree, 100, "Product C")
    print("AVL Tree Root:", avl_tree.key, avl_tree.value)

   
    print("\nBST Example")
    bst_tree = None
    bst_tree = insert_bst(bst_tree, 201, "Preference A")
    bst_tree = insert_bst(bst_tree, 202, "Preference B")
    bst_tree = insert_bst(bst_tree, 200, "Preference C")
    print("BST Root:", bst_tree.key, bst_tree.value)
    search_result = search_bst(bst_tree, 202)
    print("Search Result for Key 202:", search_result.key, search_result.value)

   
    print("\nHeap Example")
    product_heap = []
    add_to_heap(product_heap, 5, "Product X")
    add_to_heap(product_heap, 3, "Product Y")
    add_to_heap(product_heap, 4, "Product Z")

    print("Heap Contents (Priority, Product):")
    while product_heap:
        print(get_top_from_heap(product_heap))

   
    print("\nLinked List Example")
    order_list = LinkedList()
    order_list.append("Order 1")
    order_list.append("Order 2")
    order_list.append("Order 3")
    print("Orders in Linked List:")
    order_list.display()

    
    print("\nBinary Tree Example")
    binary_tree = None
    binary_tree = insert_binary_tree(binary_tree, 301, "Node A")
    binary_tree = insert_binary_tree(binary_tree, 302, "Node B")
    binary_tree = insert_binary_tree(binary_tree, 303, "Node C")
    print("Inorder Traversal of Binary Tree:")
    inorder_traversal(binary_tree)
    print()

  
    print("\nHierarchical Tree Example")
    root = TreeNode("Root", "Main Node")
    child1 = add_child(root, "Child 1", "First Child")
    child2 = add_child(root, "Child 2", "Second Child")
    add_child(child1, "Grandchild 1.1", "First Grandchild")
    add_child(child2, "Grandchild 2.1", "Second Grandchild")
    print("Tree Structure:")
    display_tree(root)
